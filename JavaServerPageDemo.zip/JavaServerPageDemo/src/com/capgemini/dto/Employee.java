package com.capgemini.dto;

public class Employee {
	
	private int eid=101;
	private String enm="Jyoti";
	private double esl=888.8;
	
	
	public Employee() {
		super();
		 
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEnm() {
		return enm;
	}
	public void setEnm(String enm) {
		this.enm = enm;
	}
	public double getEsl() {
		return esl;
	}
	public void setEsl(double esl) {
		this.esl = esl;
	}
	
	

}
